public class Room {

    private int age;
    public Room[] doorsTo;
    boolean visited = false;

    // PRE: age >= 0; doorsTo and all its elements are non-null.
    public Room(int age, Room... doorsTo) {
        this.age = age;
        this.doorsTo = doorsTo;
    }

    public int getAge() {
        return age;
    }

    public boolean isExit(){
        return (this.doorsTo.length == 0);
    }
}
