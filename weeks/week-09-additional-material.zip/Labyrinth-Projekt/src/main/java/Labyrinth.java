public class Labyrinth {

    public static void main(String[] args) {
        Room first = new Room(1, new Room(1));
        Room second = new Room(0, new Room(5), new Room(5));
        System.out.println("task1: erwartet / expected true; erhalten / actual " + task1(first));
        System.out.println("task2: erwartet / expected true; erhalten / actual " + task2(second));
    }

    // PRE: room is non-null and belongs to a finite, acyclic labyrinth.
    public static boolean task1(Room room) {
        // TODO: Find a path to an exit whose every age-prefix sum is not divisible by 3.
        return task1(room, 0);
    }
    public static boolean task1(Room room, int sum){
        if(!room.visited) {

            int newSum = sum + room.getAge();
            if (newSum % 3 == 0) {
                room.visited = false;
                return false;
            }
            if (room.isExit()) {
                room.visited = false;
                return true;
            }
            for (Room next : room.doorsTo) {
                if (task1(next, newSum)) {
                    room.visited = false;
                    return true;
                }
            }
        }
        return false;
    }

    // PRE: room is non-null and belongs to a finite, acyclic labyrinth.
    public static boolean task2(Room room) {
        // TODO: Find two distinct paths to exits with the same length and age sequence.
        return task2(room, room, true);
    }

    public static boolean task2(Room r, Room s, boolean SamePath){

        if(r.isExit() && s.isExit() && !SamePath){
            return true;
        }
        for(Room nextR : r.doorsTo){
            for(Room nextS : s.doorsTo){
                if(nextS.getAge() == nextR.getAge()){
                    if(task2(nextR, nextS, SamePath && nextR == nextS)){
                        return true;
                    }
                }
            }
        }
        return false;
    }
}







