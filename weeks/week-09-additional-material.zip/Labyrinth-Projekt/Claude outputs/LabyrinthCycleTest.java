import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

// Tests for the modified labyrinth WITH directed cycles (slides 28-56).
// task1 only considers simple paths: no room may occur twice on a solution path.
// Cycles are built by assigning doorsTo after construction.
@Timeout(10)
public class LabyrinthCycleTest {

    // Without cycle detection: b -> c -> b -> ... forever (sum stays 1).
    @Test
    public void cycleWithoutExitTerminatesWithFalse() {
        Room c = new Room(0);
        Room b = new Room(0, c);
        c.doorsTo = new Room[] {b};
        assertFalse(Labyrinth.task1(new Room(1, b)));
    }

    // The cycle door comes first, so a search without visited never reaches the exit.
    @Test
    public void exitBehindACycleIsFound() {
        Room exit = new Room(1);
        Room c = new Room(0);
        Room b = new Room(0, c);
        c.doorsTo = new Room[] {b, exit};
        assertTrue(Labyrinth.task1(new Room(1, b))); // sums 1, 1, 1, 2
    }

    @Test
    public void selfLoopIsSkipped() {
        Room exit = new Room(1);
        Room a = new Room(0);
        a.doorsTo = new Room[] {a, exit};
        assertTrue(Labyrinth.task1(new Room(1, a))); // sums 1, 1, 2
    }

    // Simple path s, x, e: sums 1, 1, 3 -> invalid.
    // Going around the cycle (s, x, y, x, e: sums 1, 1, 2, 2, 4) would be valid,
    // but x occurs twice, so this path does not count.
    @Test
    public void aRoomMayNotOccurTwiceOnAPath() {
        Room e = new Room(2);
        Room x = new Room(0);
        Room y = new Room(1, x);
        x.doorsTo = new Room[] {y, e};
        assertFalse(Labyrinth.task1(new Room(1, x)));
    }

    // visited must mean "on the current path", not "ever visited":
    // via x, the rooms m and e fail with the wrong sum and must be released again,
    // so that the path via y can use them (sums 1, 1, 1, 2).
    @Test
    public void failedRoomsAreReleasedForOtherPaths() {
        Room e = new Room(1);
        Room m = new Room(0);
        Room start = new Room(1, new Room(1, m), new Room(0, m));
        m.doorsTo = new Room[] {e, start}; // back edge to the start creates cycles
        assertTrue(Labyrinth.task1(start));
    }

    // If visited is not reset before "return true", the start room stays marked
    // and the second call returns false.
    @Test
    public void repeatedCallsOnTheSameLabyrinthGiveTheSameResult() {
        Room exit = new Room(1);
        Room c = new Room(0);
        Room b = new Room(0, c);
        c.doorsTo = new Room[] {b, exit};
        Room start = new Room(1, b);
        for (int i = 0; i < 3; i++) {
            assertTrue(Labyrinth.task1(start), "call " + (i + 1));
        }
    }

    @Test
    public void randomCyclicLabyrinthsMatchASimplePathOracle() {
        Random random = new Random(20261111L);
        for (int sample = 0; sample < 500; sample++) {
            Room[] rooms = new Room[7];
            for (int i = 0; i < rooms.length; i++) {
                rooms[i] = new Room(random.nextInt(6));
            }
            for (Room room : rooms) {
                Room[] doors = new Room[random.nextInt(4)]; // 0 doors = exit
                for (int j = 0; j < doors.length; j++) {
                    doors[j] = rooms[random.nextInt(rooms.length)]; // any room, also backwards
                }
                room.doorsTo = doors;
            }
            List<List<Room>> paths = new ArrayList<>();
            collectSimplePaths(rooms[0], new ArrayList<>(), paths);
            boolean expected = expectedTask1(paths);
            assertEquals(expected, Labyrinth.task1(rooms[0]), "sample " + sample);
            assertEquals(expected, Labyrinth.task1(rooms[0]), "sample " + sample + ", 2nd call");
        }
    }

    // Enumerates all simple paths from room to an exit (only for small inputs).
    private static void collectSimplePaths(Room room, List<Room> prefix, List<List<Room>> paths) {
        for (Room previous : prefix) {
            if (previous == room) {
                return; // room already on this path
            }
        }
        prefix.add(room);
        if (room.doorsTo.length == 0) {
            paths.add(new ArrayList<>(prefix));
        } else {
            for (Room next : room.doorsTo) {
                collectSimplePaths(next, prefix, paths);
            }
        }
        prefix.remove(prefix.size() - 1);
    }

    private static boolean expectedTask1(List<List<Room>> paths) {
        for (List<Room> path : paths) {
            int sum = 0;
            boolean valid = true;
            for (Room room : path) {
                sum += room.getAge();
                if (sum % 3 == 0) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                return true;
            }
        }
        return false;
    }
}
