import java.util.Scanner;

public class Reihe {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        System.out.println("The method reihe(" + n + ") outputs " + reihe(n));
    }

    public static double reihe(int n) {
        double sum = 0.0;

        for(int i = 1; i <= n; i = i + 1){
            sum += 1.0 / ((double) i);
        }
        return sum;
    }
}
